![](coronavirus.gif)

# Corona Virus Chat
Con el objeto de no hablarnos a la cara usaremos la comunicación electrónica mediante este chat para evitar el coronavirus

```shell
cliente.py .- Implementa las peticiones del cliente al servidor usando sockets e hilos

servidor.py.- Recibe las peticiones de múltiples clientes y las guarda en una array; para atender a los clientes hace uso de hilos

```
![Logo of the project](https://github.com/sukuzhanay/Karatsuba/blob/master/UEM-Logo.png)
